"""
November 2015
@author: Amine SEHILI <amine.sehili@gmail.com>
"""


class DuplicateArgument(Exception):
    pass
