auditok.util
------------

.. automodule:: auditok.util
   :members:
