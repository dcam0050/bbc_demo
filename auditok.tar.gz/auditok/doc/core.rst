auditok.core
------------

.. automodule:: auditok.core
   :members:
