auditok.dataset
---------------

.. automodule:: auditok.dataset
   :members: