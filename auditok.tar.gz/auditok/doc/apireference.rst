`auditok` API Reference
=======================

.. toctree::
    :titlesonly:
    :maxdepth: 3

       auditok.core <core.rst>
       auditok.util <util.rst>
       auditok.io <io.rst>
       auditok.dataset <dataset.rst>
